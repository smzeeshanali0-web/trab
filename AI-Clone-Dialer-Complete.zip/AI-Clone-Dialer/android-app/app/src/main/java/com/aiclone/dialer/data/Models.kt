package com.aiclone.dialer.data

import java.util.UUID

data class SipAccount(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val username: String,
    val password: String,
    val server: String,
    val domain: String = "",
    val ipAddress: String = "",
    val port: Int = 5060,
    val proxy: String = "",
    val authId: String = "",
    val callerId: String = "",
    val displayName: String = "",
    val transport: String = "UDP",
    val stun: String = "",
    val enabled: Boolean = true
)

/** Voice profile as reported by the backend (backend is the source of truth). */
data class VoiceProfile(
    val id: String,
    val name: String,
    val ownerName: String,
    val ownerRelation: String,
    val status: String,   // awaiting_consent | consented | cloning | ready | failed
    val error: String = ""
)

data class CallRecord(
    val id: String = UUID.randomUUID().toString(),
    val number: String,
    val startedAt: Long,
    val seconds: Int,
    val aiVoice: Boolean,
    val result: String
)

data class BackendSettings(val url: String = "", val apiKey: String = "")
